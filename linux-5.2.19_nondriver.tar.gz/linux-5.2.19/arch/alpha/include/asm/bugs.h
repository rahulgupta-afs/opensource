/*
 *  include/asm-alpha/bugs.h
 *
 *  Copyright (C) 1994  Linus Torvalds
 */

/*
 * This is included by init/main.c to check for architecture-dependent bugs.
 *
 * Needs:
 *	void check_bugs(void);
 */

/*
 * I don't know of any alpha bugs yet.. Nice chip
 */

static void check_bugs(void)
{
}
