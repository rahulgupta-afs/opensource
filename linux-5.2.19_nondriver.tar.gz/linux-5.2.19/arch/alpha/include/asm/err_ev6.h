#ifndef __ALPHA_ERR_EV6_H
#define __ALPHA_ERR_EV6_H 1

/* Dummy include for now. */

#endif /* __ALPHA_ERR_EV6_H */
