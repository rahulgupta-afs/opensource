/*
 * setup.h is part of userspace header ABI so UAPI scripts have to generate it
 * even if there's nothing to export - causing empty <uapi/asm/setup.h>
 * However to prevent "patch" from discarding it we add this placeholder
 * comment
 */
